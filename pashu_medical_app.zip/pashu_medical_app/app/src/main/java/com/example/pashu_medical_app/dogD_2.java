package com.example.pashu_medical_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class dogD_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dog_d2);
    }
}